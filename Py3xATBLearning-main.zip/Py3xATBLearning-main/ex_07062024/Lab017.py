pi = 3.14
print(pi)
print(type(pi))

i = 10
i2 = 12
result = i2/i
print(result) # Python is very smart, it knows that 12/10 is a float
print(type(result))