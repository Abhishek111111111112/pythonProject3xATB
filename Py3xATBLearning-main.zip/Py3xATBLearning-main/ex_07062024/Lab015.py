# Advance Data Type in Python
# List, Tuple, Set, Dict - DS - API and Web Automation.
# Take a user input
user_input = input("Enter your name: ")
print(user_input)
print(type(user_input))