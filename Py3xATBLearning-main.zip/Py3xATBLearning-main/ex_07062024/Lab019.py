# Format String
print(2 * 1)
num = 90
print(f"The number is {num * 2}")
print(f"The number is {num * 3}")

num = 5
print(f"{num}x1={num}")
print(f"{num}x2={num * 2}")
print(f"{num}x3={num * 3}")
print(f"{num}x10={num * 10}")

b = 1
print(f"{b}x1={b}")
print("2x{}={},{}".format(b, b * 2, 3))
# This is just use to showcase the output.
