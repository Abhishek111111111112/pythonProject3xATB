print("Hello World")
# Commment
# Varaible
# Data Types in Python
# int, str, float, complex, bool
# int
a = 10
print(a)
# str
b = "Hello"
print(b)
# float
c = 10.5
print(c)
# complex
d = 10 + 5j
print(d)
# bool
e = True
print(e)
print(type(a))