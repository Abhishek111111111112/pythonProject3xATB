# Escape Seq
print("Hello \"World\"")
print("Hello \nWorld")
print("Hello \tWorld")
print("Hello \bWorld")