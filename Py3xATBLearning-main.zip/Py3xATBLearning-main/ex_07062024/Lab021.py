name = "This is a Big line"
print(len(name))
print(type(name))
print(name[14])
print(name[-1])
print(name[-2])
print(name[-10])