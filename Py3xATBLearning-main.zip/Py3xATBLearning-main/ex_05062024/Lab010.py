# variable name should be start grom A-Z, a-z _
name = "Pramod"
print(type(name))

# variable name should not start with number
# 123 =345 - variable names


# variable name should not be any keyword
# keyword ? // Reserved word
# 'False', 'None', 'True', 'and', 'as', 'assert', 'async', 'await', 'break', 'class', 'continue', 'def', 'del', 'elif', 'else', 'except', 'finally', 'for', 'from', 'global', 'if', 'import', 'in', 'is', 'lambda', 'nonlocal', 'not', 'or', 'pass', 'raise', 'return', 'try', 'while', 'with', 'yield' [2]
# and = 123

# variable name should not be any special character
# @ = 123
# $ = 344
_ = 123
_name = "pramod"
# $prampod = "pramod"
# pramod$ = "Hello"

# variable name should not be any space
# first name = "Pramod"
first_name = "Pramod"
# Python love the snake case
varaible_name = "pramod"

long_var_name_is_created_here = "Hello"
