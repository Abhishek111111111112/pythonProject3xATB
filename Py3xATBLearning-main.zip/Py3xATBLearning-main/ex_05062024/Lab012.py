# a = 10
# b = 20
# c = 30
# print(a+b+c)

a, b, c = 10, 20, 30
print(a + b + c)
