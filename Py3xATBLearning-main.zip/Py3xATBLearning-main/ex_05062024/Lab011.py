# Numbers
# Integer (whole)
age = 78
age = -90
roll_number = 123
phone_number = 9876543210

print(type(age))

pi = 3.14
gst = 0.18
pi = -3.14

print(type(pi))

isMarried = True
isSantoshMarried = False

name = "Pramod"
name2 = 'Pramod'
name3 = """Pramod
dasdasd
das
dasd
asd
as
das
da
sd
asd
a
"""

print(type(name))
print(type(name2))
print(type(name3))
