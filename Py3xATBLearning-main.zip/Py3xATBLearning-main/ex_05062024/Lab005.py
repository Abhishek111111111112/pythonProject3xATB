# print(sep="-", "Hi", "Pramod")
print("I am Good Person", end="_")
print("I am Bad Person")
# Python is case sensitive
#Print("Hi")