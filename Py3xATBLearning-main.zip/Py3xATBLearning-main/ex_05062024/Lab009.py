age = 65
# Dynamically typed
print(type(age))
age = "sixty five"
print(type(age))