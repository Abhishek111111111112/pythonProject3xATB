# Take an input from the username, and print it.
first_name = input("Enter your First name")
last_name = input("Enter your Last name")
print("Your first name is ", first_name, "and your last name is ", last_name)
