print("Hi", "Pramod", "Dutta",sep="-",end="\t")
print("Hi", "Pramod", "Dutta")
