# print()
# self - Concept in OOps which points to inself - ignore.
# *args - Unlimited number of arguments * - string, int, float, boolean...
# sep=' ' - How you want to seperate the arguments
# end='\n' - in the end what you want to do
# file=None - File IO


# print("Hello", "World", 123, True, 3.14)
print("Hi, My name is Pramod", "Dutta",sep=" - ")
